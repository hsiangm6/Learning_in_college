
function email(){
    var passcode=prompt("Enter passcode to show email:")
    while(passcode!="web"){
        alert("Sorry, incorrect passcode.");
        var passcode=prompt("Enter passcode to show email:")
    }
    var button=document.getElementById("button");
    var email="e910425@gmail.com"//prompt("Enter your email:");
    var text=document.getElementById('email');
    text.innerHTML=email;
    button.style.display="none";
    

}